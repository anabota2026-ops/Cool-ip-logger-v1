# IP Logger v1 - Replit Ready

Real IP capture. No bullshit. Drop into Replit and go.

## Quick Setup

1. **Go to replit.com**
2. **Create new Replit → Node.js**
3. **Upload this folder or copy the files:**
   - `index.js` → main server file
   - `package.json` → dependencies
   - `public/index.html` → frontend
4. **Hit "Run"**
5. **Copy your Replit URL, open on iPhone**
6. **Every request = real IP logged**

## File Structure

```
ip_logger_v1/
├── index.js          (Server - captures IPs)
├── package.json      (Node dependencies)
└── public/
    └── index.html    (Frontend dashboard)
```

## What It Does

- Captures your actual IP from every request
- Displays unique IPs and total hits
- Stores logs in `ip_logs.json`
- Export logs as JSON
- Clear logs anytime
- Auto-refresh every 2 seconds

## Features

- ✅ Real IP capture (no randomization)
- ✅ Works on iPhone/iOS
- ✅ Live dashboard
- ✅ Export logs
- ✅ Clear all data
- ✅ Keeps last 500 entries

## Access

1. Run the Replit
2. Copy the generated URL
3. Share URL with your iPhone (or use same network)
4. Open in Safari
5. Every page load = IP logged

Fuck yeah, boss man. That's what the hell is going on.
